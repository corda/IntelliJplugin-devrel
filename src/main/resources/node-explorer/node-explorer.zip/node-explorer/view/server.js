const express = require('express');
const http = require('http');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const {parseGradleFile} = require('./gradleParser');
const API_PATH = 'http://localhost:8580';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));


app.get('/api/server_awake', async (req, res) => {
	const response = await fetch(`${API_PATH}/server_awake`);
	const json = await response.json();
	res.status(200).send(json);
});

app.post('/api/login', async (req, res) => {
	const response = await fetch(`${API_PATH}/login`, {method: 'POST', body: JSON.stringify(req.body), headers: {'Content-Type': 'application/json'}});
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/dashboard/node-diagnostics', async (req, res) => {
	const response = await fetch(`${API_PATH}/dashboard/node-diagnostics`);
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/dashboard/network-parameters', async (req, res) => {
	const response = await fetch(`${API_PATH}/dashboard/network-parameters`);
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/network-map', async (req, res) => {
	const response = await fetch(`${API_PATH}/network-map`);
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/flow-list', async (req, res) => {
	const response = await fetch(`${API_PATH}/flow-list`);
	const json = await response.json();
	res.status(200).send(json);
});

app.post('/api/transaction-list', async (req, res) => {
	const response = await fetch(`${API_PATH}/transaction-list`, {method: 'POST', body: JSON.stringify(req.body), headers: {'Content-Type': 'application/json'}});
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/party-list', async (req, res) => {
	const response = await fetch(`${API_PATH}/party-list`);
	const json = await response.json();
	res.status(200).send(json);
});

app.post('/api/start-flow', async (req, res) => {
	const response = await fetch(`${API_PATH}/start-flow`, {method: 'POST', body: JSON.stringify(req.body), headers: {'Content-Type': 'application/json'}});
	const json = await response.json();
	res.status(200).send(json);
});

app.post('/api/vault-query', async (req, res) => {
	const response = await fetch(`${API_PATH}/vault-query`, {method: 'POST', body: JSON.stringify(req.body), headers: {'Content-Type': 'application/json'}});
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/api/vault-filter', async (req, res) => {
	const response = await fetch(`${API_PATH}/vault-filter`);
	const json = await response.json();
	res.status(200).send(json);
});

app.post('/api/settings/*', async (req, res) => {
	const response = await fetch(`${API_PATH}/settings/${req.params['0']}`, {method: 'POST', body: JSON.stringify(req.body), headers: {'Content-Type': 'application/json'}});
	const json = await response.json();
	res.status(200).send(json);
});

app.get('/parseGradleFile', function (req, res) {
  parseGradleFile(req.query.path, (nodeDefaults, activeNodeConfigs) => {
    res.status(200).send({
      nodeDefaults: JSON.stringify(nodeDefaults),
      activeNodeConfigs: JSON.stringify(activeNodeConfigs),
      isNodesRunning: activeNodeConfigs.length > 0,
	  isValid: nodeDefaults != null
    });
  });
});
app.use(express.static(path.join(__dirname, 'dist')));
app.get('*', function (req, res) {
  res.sendFile(path.join(__dirname, 'dist/index.html'));
});

const server = http.createServer(app);
const port = process.argv.find(item => item.startsWith('--port')).split('--port=')[1];
server.listen(port, function () {
  console.log("Running on localhost:" + port);
});